library(devtools)

# usethis::use_git()

# usethis::use_r('strsplit1')

#devtools::load_all()

# exists("strsplit1", where = globalenv(), inherits = FALSE)

#usethis::create_github_token()

#gitcreds::gitcreds_set()

check()
